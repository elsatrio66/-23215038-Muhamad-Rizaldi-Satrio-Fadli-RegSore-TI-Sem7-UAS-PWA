"use strict";
var app = (function () {
  var isSubscribed = false;
  var swRegistration = null;
  var notifyButton = document.querySelector(".js-notify-btn");
  var pushButton = document.querySelector(".js-push-btn");
  if (!("Notification" in window)) {
    console.log("Notifications not supported in this browser");
    return;
  }
  Notification.requestPermission(function (status) {
    console.log("Notification permission status:", status);
  });

  Notification.requestPermission().then(function (permission) {
    if (permission == "granted") {
      alert("Terima kasih sudah accept");
    } else if (permission == "denied") {
      alert("Pemberitahuan Web Telah di Blok");
    }
  });

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./service-worker.js").then(function () {
      console.log("Service Worker Registered");
    });
  }
})();
